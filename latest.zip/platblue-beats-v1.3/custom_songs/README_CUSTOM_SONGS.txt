Put custom songs here

Having a lot custom songs will drastically increase game starting time

How to make your own custom song:
Use custom song creation tool in-game, or do it manually:
- Create a folder for a songs (name of this folder won't be visible in-game)
- Inside you should put/create 4 files: cover.png, info.ini, song.ogg, map.bin

cover.png - Song cover image displayed in song selection menu
info.ini - Info about song, like: name, difficulty and more
song.ogg - Song file itself
map.bin - Map created in in-game editor


REMEMBER: Custom song folder name should not have any spaces or special characters other then - _