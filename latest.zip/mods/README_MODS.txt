Put mod folders here

Mods replace assets file

You can create your own mod by using empty-mod example

REMEMBER: Mod folder name should not have any spaces or special characters other then - _